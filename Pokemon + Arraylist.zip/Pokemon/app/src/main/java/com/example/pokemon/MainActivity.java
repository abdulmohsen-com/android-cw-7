package com.example.pokemon;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Pokemon p1 = new Pokemon("Pikachu",R.drawable.pikachu, 55, 40, 320);
        Pokemon p2 = new Pokemon("Eevee",R.drawable.eevee, 55, 50, 325);
        Pokemon p3 = new Pokemon("Arceus",R.drawable.arceus, 120, 120, 720);
        ArrayList<Pokemon> pokeball = new ArrayList<>();
        pokeball.add(p1);
        pokeball.add(p2);
        pokeball.add(p3);

    }
}